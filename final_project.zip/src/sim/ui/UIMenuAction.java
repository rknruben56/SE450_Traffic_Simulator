package sim.ui;

/**
 * Interface for the individual menu actions
 * 
 * @author rodri_000
 *
 */
public interface UIMenuAction {
	public void run();
}
