package sim.agent;

/**
 * 
 * Interface for running classes in the Time Server
 * 
 * @author rodri_000
 *
 */
public interface Agent {
	public void run();
}
